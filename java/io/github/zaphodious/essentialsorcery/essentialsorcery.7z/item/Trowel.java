package io.github.zaphodious.essentialsorcery.item;

import net.minecraft.item.ItemSpade;

public class Trowel extends ItemSpade {

	public Trowel(String unlocalizedName, ToolMaterial material) {
		super(material);
		this.setUnlocalizedName(unlocalizedName);
		
	}

}

package io.github.zaphodious.essentialsorcery.item;

import net.minecraft.item.ItemStack;

public interface IMetaBlockName {

	String getSpecialName(ItemStack stack);
	
}

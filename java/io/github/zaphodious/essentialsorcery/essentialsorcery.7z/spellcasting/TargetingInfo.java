package io.github.zaphodious.essentialsorcery.spellcasting;

public class TargetingInfo {

	
	
}
